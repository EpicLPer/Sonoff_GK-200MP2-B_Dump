#!/bin/ash
# Wait 30 second to prepare remount all filesystems and prepare /etc/ in ramdisk
sleep 30

# Print information about start of the actual hack to the console
i=1; while [ $i -le 20 ] ; do echo "--- APPLYING SSH HACK ---"; i=$((i+1)) ; done

# Setting new root password and changing home dir in order to allow ssh login
# Pre-generated password is "sshhack". You can generate your own using "mkpasswd -5" command and replace MD5 string in shadow file
cp /tmp/shadow /etc
cp /tmp/passwd /etc

# Start SSH server
/tmp/dropbearmulti dropbear -r /tmp/dropbear_ecdsa_host_key
