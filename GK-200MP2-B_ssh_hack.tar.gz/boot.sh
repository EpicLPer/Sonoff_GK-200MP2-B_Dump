#!/bin/ash
# Print information about start of the hack to the console
i=1; while [ $i -le 20 ] ; do echo "--- PREPARATION FOR SSH HACK ---"; i=$((i+1)) ; done

# Copy all necessary files for SSH hack to ramdisk (/tmp)
cp /var/sdcard/GK-200MP2-B_hack/passwd /tmp
cp /var/sdcard/GK-200MP2-B_hack/shadow /tmp
cp /var/sdcard/GK-200MP2-B_hack/dropbearmulti /tmp
cp /var/sdcard/GK-200MP2-B_hack/dropbear_ecdsa_host_key /tmp
cp /var/sdcard/GK-200MP2-B_hack/hack.sh /tmp

# Execute main script in background in order to let camera to boot up
ash /tmp/hack.sh &
